package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class Project(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val clientName: String,
    val clientPhone: String,
    val projectName: String,
    val dateCreated: Long = System.currentTimeMillis(),
    val totalCost: Double = 0.0,
    val finalPrice: Double = 0.0,
    val depositPaid: Double = 0.0,
    val deliveryDate: Long = 0,
    val isCompleted: Boolean = false,
    val notes: String = ""
)

@Entity(tableName = "measurements")
data class Measurement(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val projectId: Int,
    val itemName: String,
    val height: Double,
    val width: Double,
    val depth: Double,
    val notes: String = ""
)

@Entity(tableName = "material_costs")
data class MaterialCost(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val projectId: Int,
    val materialName: String,
    val unitType: String, // e.g., "لوح", "متر", "حبة"
    val unitCost: Double,
    val quantity: Double,
    val totalCost: Double = unitCost * quantity
)

@Entity(tableName = "payments")
data class Payment(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val projectId: Int,
    val amount: Double,
    val date: Long = System.currentTimeMillis(),
    val notes: String = ""
)

@Entity(tableName = "wood_panels")
data class WoodPanel(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val length: Double, // in cm
    val width: Double,  // in cm
    val price: Double   // Price in base currency (USD)
)


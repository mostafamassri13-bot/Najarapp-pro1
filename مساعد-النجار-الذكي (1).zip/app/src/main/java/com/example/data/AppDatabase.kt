package com.example.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CarpenterDao {
    // Projects
    @Query("SELECT * FROM projects ORDER BY dateCreated DESC")
    fun getAllProjects(): Flow<List<Project>>

    @Query("SELECT * FROM projects WHERE id = :id")
    fun getProjectById(id: Int): Flow<Project?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: Project): Long

    @Update
    suspend fun updateProject(project: Project)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun deleteProjectById(id: Int)

    // Measurements
    @Query("SELECT * FROM measurements WHERE projectId = :projectId ORDER BY id ASC")
    fun getMeasurementsByProject(projectId: Int): Flow<List<Measurement>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMeasurement(measurement: Measurement)

    @Query("DELETE FROM measurements WHERE id = :id")
    suspend fun deleteMeasurementById(id: Int)

    @Query("DELETE FROM measurements WHERE projectId = :projectId")
    suspend fun deleteMeasurementsByProject(projectId: Int)

    // Material Costs
    @Query("SELECT * FROM material_costs WHERE projectId = :projectId ORDER BY id ASC")
    fun getMaterialCostsByProject(projectId: Int): Flow<List<MaterialCost>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMaterialCost(materialCost: MaterialCost)

    @Query("DELETE FROM material_costs WHERE id = :id")
    suspend fun deleteMaterialCostById(id: Int)

    @Query("DELETE FROM material_costs WHERE projectId = :projectId")
    suspend fun deleteMaterialCostsByProject(projectId: Int)

    // Payments
    @Query("SELECT * FROM payments WHERE projectId = :projectId ORDER BY date DESC")
    fun getPaymentsByProject(projectId: Int): Flow<List<Payment>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: Payment)

    @Query("DELETE FROM payments WHERE id = :id")
    suspend fun deletePaymentById(id: Int)

    @Query("DELETE FROM payments WHERE projectId = :projectId")
    suspend fun deletePaymentsByProject(projectId: Int)

    // Wood Panels Database
    @Query("SELECT * FROM wood_panels ORDER BY id DESC")
    fun getAllWoodPanels(): Flow<List<WoodPanel>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWoodPanel(panel: WoodPanel)

    @Update
    suspend fun updateWoodPanel(panel: WoodPanel)

    @Query("DELETE FROM wood_panels WHERE id = :id")
    suspend fun deleteWoodPanelById(id: Int)

    // Sync methods for Cloud Backup & Restore
    @Query("SELECT * FROM projects")
    suspend fun getAllProjectsSync(): List<Project>

    @Query("SELECT * FROM measurements")
    suspend fun getAllMeasurementsSync(): List<Measurement>

    @Query("SELECT * FROM material_costs")
    suspend fun getAllMaterialCostsSync(): List<MaterialCost>

    @Query("SELECT * FROM payments")
    suspend fun getAllPaymentsSync(): List<Payment>

    @Query("SELECT * FROM wood_panels")
    suspend fun getAllWoodPanelsSync(): List<WoodPanel>

    @Query("DELETE FROM projects")
    suspend fun deleteAllProjects()

    @Query("DELETE FROM measurements")
    suspend fun deleteAllMeasurements()

    @Query("DELETE FROM material_costs")
    suspend fun deleteAllMaterialCosts()

    @Query("DELETE FROM payments")
    suspend fun deleteAllPayments()

    @Query("DELETE FROM wood_panels")
    suspend fun deleteAllWoodPanels()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProjects(projects: List<Project>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMeasurements(measurements: List<Measurement>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMaterialCosts(costs: List<MaterialCost>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayments(payments: List<Payment>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWoodPanels(panels: List<WoodPanel>)
}

@Database(
    entities = [Project::class, Measurement::class, MaterialCost::class, Payment::class, WoodPanel::class],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun carpenterDao(): CarpenterDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "carpenter_assistant_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

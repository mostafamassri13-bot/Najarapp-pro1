package com.example.data

import java.util.UUID

data class BoardType(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val length: Double,
    val width: Double,
    val price: Double
)

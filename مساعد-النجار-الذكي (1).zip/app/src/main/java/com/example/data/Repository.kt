package com.example.data

import kotlinx.coroutines.flow.Flow

class CarpenterRepository(private val dao: CarpenterDao) {

    val allProjects: Flow<List<Project>> = dao.getAllProjects()

    fun getProjectById(id: Int): Flow<Project?> = dao.getProjectById(id)

    suspend fun insertProject(project: Project): Int {
        return dao.insertProject(project).toInt()
    }

    suspend fun updateProject(project: Project) {
        dao.updateProject(project)
    }

    suspend fun deleteProjectById(id: Int) {
        dao.deleteProjectById(id)
        dao.deleteMeasurementsByProject(id)
        dao.deleteMaterialCostsByProject(id)
        dao.deletePaymentsByProject(id)
    }

    fun getMeasurementsForProject(projectId: Int): Flow<List<Measurement>> =
        dao.getMeasurementsByProject(projectId)

    suspend fun insertMeasurement(measurement: Measurement) {
        dao.insertMeasurement(measurement)
    }

    suspend fun deleteMeasurementById(id: Int) {
        dao.deleteMeasurementById(id)
    }

    fun getMaterialCostsForProject(projectId: Int): Flow<List<MaterialCost>> =
        dao.getMaterialCostsByProject(projectId)

    suspend fun insertMaterialCost(materialCost: MaterialCost) {
        dao.insertMaterialCost(materialCost)
    }

    suspend fun deleteMaterialCostById(id: Int) {
        dao.deleteMaterialCostById(id)
    }

    fun getPaymentsForProject(projectId: Int): Flow<List<Payment>> =
        dao.getPaymentsByProject(projectId)

    suspend fun insertPayment(payment: Payment) {
        dao.insertPayment(payment)
    }

    suspend fun deletePaymentById(id: Int) {
        dao.deletePaymentById(id)
    }

    // Wood Panels Database
    val allWoodPanels: Flow<List<WoodPanel>> = dao.getAllWoodPanels()

    suspend fun insertWoodPanel(panel: WoodPanel) {
        dao.insertWoodPanel(panel)
    }

    suspend fun updateWoodPanel(panel: WoodPanel) {
        dao.updateWoodPanel(panel)
    }

    suspend fun deleteWoodPanelById(id: Int) {
        dao.deleteWoodPanelById(id)
    }
}

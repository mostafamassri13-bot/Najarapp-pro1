package com.example.ui

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MaterialCost
import com.example.data.Measurement
import com.example.data.Payment
import com.example.data.Project
import java.text.SimpleDateFormat
import java.util.*
import android.graphics.BitmapFactory
import android.net.Uri
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.File
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.PictureAsPdf

@Composable
fun ProjectDetailsScreen(
    viewModel: CarpenterViewModel,
    modifier: Modifier = Modifier
) {
    val project by viewModel.currentProject.collectAsState()
    val measurements by viewModel.currentMeasurements.collectAsState()
    val materials by viewModel.currentMaterials.collectAsState()
    val payments by viewModel.currentPayments.collectAsState()

    var activeTab by remember { mutableStateOf(0) }
    val tabTitles = listOf("القياسات 📏", "المواد والتكلفة 🪵", "الحساب والدفعات 💰", "الفاتورة والمشاركة 📄")

    val context = LocalContext.current

    if (project == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    val currentProj = project!!

    Scaffold { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Header with Back action
            AppHeader(
                title = currentProj.projectName,
                subtitle = "الزبون: ${currentProj.clientName} | ${currentProj.clientPhone}",
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "الرجوع",
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                },
                actions = {
                    // Export to Cutting list button
                    if (measurements.isNotEmpty()) {
                        IconButton(
                            onClick = { viewModel.importMeasurementsToOptimizer() },
                            modifier = Modifier
                                .background(
                                    color = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(8.dp)
                                )
                        ) {
                            Icon(
                                imageVector = Icons.Default.GridOn,
                                contentDescription = "تصدير للقص",
                                tint = MaterialTheme.colorScheme.tertiary
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                    }

                    var showCurrencyDialog by remember { mutableStateOf(false) }
                    IconButton(
                        onClick = { showCurrencyDialog = true },
                        modifier = Modifier
                            .background(
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                                shape = RoundedCornerShape(8.dp)
                            )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Paid,
                            contentDescription = "إعدادات العملة",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    if (showCurrencyDialog) {
                        CurrencySettingsDialog(
                            viewModel = viewModel,
                            onDismiss = { showCurrencyDialog = false }
                        )
                    }
                }
            )

            // Tabs for subsections
            ScrollableTabRow(
                selectedTabIndex = activeTab,
                edgePadding = 16.dp,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[activeTab]),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            ) {
                tabTitles.forEachIndexed { index, title ->
                    Tab(
                        selected = activeTab == index,
                        onClick = { activeTab = index },
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (activeTab == index) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 14.sp
                            )
                        }
                    )
                }
            }

            // Tab Contents
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                when (activeTab) {
                    0 -> MeasurementsTab(
                        measurements = measurements,
                        onAdd = { name, h, w, d, notes ->
                            viewModel.addMeasurement(name, h, w, d, notes)
                        },
                        onDelete = { id -> viewModel.deleteMeasurement(id) },
                        onExportToOptimizer = { viewModel.importMeasurementsToOptimizer() }
                    )
                    1 -> MaterialsTab(
                        materials = materials,
                        viewModel = viewModel,
                        onAdd = { name, type, cost, qty ->
                            viewModel.addMaterialCost(name, type, cost, qty)
                        },
                        onDelete = { id -> viewModel.deleteMaterialCost(id) }
                    )
                    2 -> PricingPaymentsTab(
                        project = currentProj,
                        payments = payments,
                        viewModel = viewModel,
                        onUpdatePrice = { price, notes ->
                            viewModel.updateProjectPricing(currentProj.id, price, notes)
                        },
                        onAddPayment = { amt, notes ->
                            viewModel.addPayment(amt, notes)
                        },
                        onDeletePayment = { id -> viewModel.deletePayment(id) }
                    )
                    3 -> InvoiceTab(
                        project = currentProj,
                        measurements = measurements,
                        materials = materials,
                        payments = payments,
                        viewModel = viewModel
                    )
                }
            }
        }
    }
}

// ==========================================
// Sub-Tab 1: Measurements (دفتر القياسات)
// ==========================================
@Composable
fun MeasurementsTab(
    measurements: List<Measurement>,
    onAdd: (name: String, h: Double, w: Double, d: Double, notes: String) -> Unit,
    onDelete: (Int) -> Unit,
    onExportToOptimizer: () -> Unit
) {
    var itemName by remember { mutableStateOf("") }
    var height by remember { mutableStateOf("") }
    var width by remember { mutableStateOf("") }
    var depth by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    // Quick Templates (نماذج قياسية جاهزة)
    val templates = listOf(
        Triple("دولاب مطبخ علوي قياسي", 70.0, 35.0),
        Triple("دولاب مطبخ سفلي قياسي", 90.0, 60.0),
        Triple("عمق خزانة ملابس قياسي", 200.0, 60.0),
        Triple("مكتب عمل MDF قياسي", 75.0, 60.0),
        Triple("درج مطبخ قياسي", 15.0, 50.0)
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Form to Add New Measurement
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "تسجيل مقاس جديد 📏",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = itemName,
                        onValueChange = { itemName = it },
                        label = { Text("اسم الجزء (مثال: درفة علوية 1)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Templates Picker
                    Text(
                        text = "النماذج القياسية السريعة:",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        templates.take(3).forEach { (tName, tH, tD) ->
                            Text(
                                text = tName.replace(" قياسي", ""),
                                style = MaterialTheme.typography.labelMedium.copy(
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold
                                ),
                                modifier = Modifier
                                    .background(
                                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                                        shape = RoundedCornerShape(6.dp)
                                    )
                                    .clickable {
                                        itemName = tName
                                        height = tH.toString()
                                        depth = tD.toString()
                                    }
                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = height,
                            onValueChange = { height = it },
                            label = { Text("الارتفاع (سم)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )
                        OutlinedTextField(
                            value = width,
                            onValueChange = { width = it },
                            label = { Text("العرض (سم)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )
                        OutlinedTextField(
                            value = depth,
                            onValueChange = { depth = it },
                            label = { Text("العمق (سم)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("ملاحظات خاصة (أماكن مواسير، أفياش كهرباء...)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            val h = height.toDoubleOrNull() ?: 0.0
                            val w = width.toDoubleOrNull() ?: 0.0
                            val d = depth.toDoubleOrNull() ?: 0.0
                            if (itemName.isNotBlank() && h > 0 && w > 0) {
                                onAdd(itemName, h, w, d, notes)
                                itemName = ""
                                height = ""
                                width = ""
                                depth = ""
                                notes = ""
                            }
                        },
                        enabled = itemName.isNotBlank() && height.isNotBlank() && width.isNotBlank(),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("حفظ المقاس")
                    }
                }
            }
        }

        // Action Row
        if (measurements.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "القياسات المسجلة (${measurements.size})",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )

                    Button(
                        onClick = onExportToOptimizer,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.tertiary,
                            contentColor = MaterialTheme.colorScheme.onTertiary
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Transform, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("قص الألواح ذكياً", fontSize = 12.sp)
                    }
                }
            }
        }

        // Measurements List
        if (measurements.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    EmptyStateWidget(
                        icon = Icons.Default.SquareFoot,
                        message = "لا توجد قياسات مسجلة لهذا المشروع.\nسجل مقاساً في النموذج أعلاه للبدء."
                    )
                }
            }
        } else {
            items(measurements, key = { it.id }) { m ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = m.itemName,
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "الارتفاع: ${m.height} سم",
                                    style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.primary)
                                )
                                Text(
                                    text = "العرض: ${m.width} سم",
                                    style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.secondary)
                                )
                                if (m.depth > 0) {
                                    Text(
                                        text = "العمق: ${m.depth} سم",
                                        style = MaterialTheme.typography.bodyMedium.copy(color = Color(0xFF4CAF50))
                                    )
                                }
                            }
                            if (m.notes.isNotBlank()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Info,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = m.notes,
                                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                                    )
                                }
                            }
                        }

                        IconButton(onClick = { onDelete(m.id) }) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "حذف",
                                tint = Color(0xFFE53935).copy(alpha = 0.8f)
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// Sub-Tab 2: Materials list (تكلفة المواد الخام)
// ==========================================
@Composable
fun MaterialsTab(
    materials: List<MaterialCost>,
    viewModel: CarpenterViewModel,
    onAdd: (name: String, unitType: String, cost: Double, qty: Double) -> Unit,
    onDelete: (Int) -> Unit
) {
    var materialName by remember { mutableStateOf("") }
    var unitType by remember { mutableStateOf("لوح") }
    var unitCost by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("") }

    val totalMaterialsCost = materials.sumOf { it.unitCost * it.quantity }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Material Input Form
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "تسجيل تكلفة مادة خام 🪵",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = materialName,
                        onValueChange = { materialName = it },
                        label = { Text("اسم المادة (مثال: لوح MDF 18مم، مقابض، غراء...)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    val dbPanels by viewModel.woodPanels.collectAsState()
                    if (dbPanels.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "اختر سريعاً من قاعدة الخامات 🪵:",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        androidx.compose.foundation.lazy.LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(dbPanels) { panel ->
                                val panelPrice = when (viewModel.selectedCurrency) {
                                    AppCurrency.USD -> panel.price
                                    AppCurrency.SYP -> panel.price * viewModel.usdToSypRate
                                    AppCurrency.SAR -> panel.price * viewModel.usdToSarRate
                                }
                                AssistChip(
                                    onClick = {
                                        materialName = panel.name
                                        unitType = "لوح"
                                        unitCost = String.format(java.util.Locale.US, "%.2f", panelPrice)
                                    },
                                    label = {
                                        Text("${panel.name} (${String.format(java.util.Locale.US, "%.0f", panel.length)}×${String.format(java.util.Locale.US, "%.0f", panel.width)}سم)")
                                    },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = Icons.Default.Layers,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Custom dropdown for unit type
                        var expanded by remember { mutableStateOf(false) }
                        Box(modifier = Modifier.weight(1.2f)) {
                            OutlinedTextField(
                                value = unitType,
                                onValueChange = {},
                                label = { Text("الوحدة") },
                                readOnly = true,
                                trailingIcon = {
                                    IconButton(onClick = { expanded = !expanded }) {
                                        Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null)
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            )
                            DropdownMenu(
                                expanded = expanded,
                                onDismissRequest = { expanded = false }
                            ) {
                                listOf("لوح", "متر مربع", "متر طولي", "حبة", "كيس", "طقم", "أخرى").forEach { option ->
                                    DropdownMenuItem(
                                        text = { Text(option) },
                                        onClick = {
                                            unitType = option
                                            expanded = false
                                        }
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = unitCost,
                            onValueChange = { unitCost = it },
                            label = { Text("سعر الوحدة") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )

                        OutlinedTextField(
                            value = quantity,
                            onValueChange = { quantity = it },
                            label = { Text("الكمية") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            val cost = unitCost.toDoubleOrNull() ?: 0.0
                            val qty = quantity.toDoubleOrNull() ?: 0.0
                            if (materialName.isNotBlank() && cost > 0 && qty > 0) {
                                onAdd(materialName, unitType, cost, qty)
                                materialName = ""
                                unitCost = ""
                                quantity = ""
                            }
                        },
                        enabled = materialName.isNotBlank() && unitCost.isNotBlank() && quantity.isNotBlank(),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.AddCircle, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("إضافة لقائمة التكاليف")
                    }
                }
            }
        }

        // Live Total Card
        if (materials.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "مجموع تكلفة المواد الخام:",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = viewModel.formatCurrency(totalMaterialsCost),
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        )
                    }
                }
            }
        }

        // Materials List
        if (materials.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    EmptyStateWidget(
                        icon = Icons.Default.ViewAgenda,
                        message = "لا توجد مواد مضافة لمخزون المشروع.\nأضف مواد مثل (ألواح خشب، إكسسوارات) لحساب التكلفة التلقائية."
                    )
                }
            }
        } else {
            items(materials, key = { it.id }) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = item.materialName,
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "الكمية: ${item.quantity} ${item.unitType} × ${viewModel.formatCurrency(item.unitCost)}",
                                style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = viewModel.formatCurrency(item.totalCost),
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            IconButton(onClick = { onDelete(item.id) }) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "حذف",
                                    tint = Color(0xFFE53935).copy(alpha = 0.8f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// Sub-Tab 3: Pricing & Payments (الحساب والدفعات)
// ==========================================
@Composable
fun PricingPaymentsTab(
    project: Project,
    payments: List<Payment>,
    viewModel: CarpenterViewModel,
    onUpdatePrice: (Double, String) -> Unit,
    onAddPayment: (Double, String) -> Unit,
    onDeletePayment: (Int) -> Unit
) {
    var contractPrice by remember(project.finalPrice) { mutableStateOf(project.finalPrice.toString()) }
    var notesInput by remember { mutableStateOf("") }

    var paymentAmount by remember { mutableStateOf("") }
    var paymentNotes by remember { mutableStateOf("") }

    val remainingBalance = project.finalPrice - project.depositPaid

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Contract Pricing Card (عقد الاتفاق)
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "التسعير الإجمالي للعميل 💵",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "تكلفة المواد الخام الحالية: ${viewModel.formatCurrency(project.totalCost)}",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = contractPrice,
                        onValueChange = { contractPrice = it },
                        label = { Text("السعر النهائي المتفق عليه مع الزبون (${viewModel.selectedCurrency.symbol})") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            val price = contractPrice.toDoubleOrNull() ?: 0.0
                            if (price > 0) {
                                onUpdatePrice(price, notesInput)
                                notesInput = ""
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("تحديث السعر والاتفاق")
                    }
                }
            }
        }

        // Ledger Summary Row
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                        Text(text = "قيمة العقد الكلية", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)))
                        Text(text = viewModel.formatCurrency(project.finalPrice), style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary))
                    }
                    Box(modifier = Modifier.width(1.dp).height(40.dp).background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f)))
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                        Text(text = "المسدد (الدفعات)", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)))
                        Text(text = viewModel.formatCurrency(project.depositPaid), style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = Color(0xFF4CAF50)))
                    }
                    Box(modifier = Modifier.width(1.dp).height(40.dp).background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f)))
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                        Text(text = "المتبقي للاستلام", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)))
                        Text(text = viewModel.formatCurrency(maxOf(0.0, remainingBalance)), style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = if (remainingBalance > 0) Color(0xFFE53935) else Color(0xFF4CAF50)))
                    }
                }
            }
        }

        // Add Payment Form
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0xFF4CAF50).copy(alpha = 0.2f)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "تسجيل دفعة مستلمة جديدة 💸",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF4CAF50)
                        )
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = paymentAmount,
                            onValueChange = { paymentAmount = it },
                            label = { Text("قيمة الدفعة (${viewModel.selectedCurrency.symbol})") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1.2f),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )
                        OutlinedTextField(
                            value = paymentNotes,
                            onValueChange = { paymentNotes = it },
                            label = { Text("طريقة الدفع/البيان (كاش، تحويل...)") },
                            modifier = Modifier.weight(2f),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            val amt = paymentAmount.toDoubleOrNull() ?: 0.0
                            if (amt > 0) {
                                onAddPayment(amt, paymentNotes)
                                paymentAmount = ""
                                paymentNotes = ""
                            }
                        },
                        enabled = paymentAmount.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50), contentColor = Color.White),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تسجيل المقبوضات")
                    }
                }
            }
        }

        // Payments History List
        item {
            Text(
                text = "سجل المقبوضات والدفعات (${payments.size})",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        }

        if (payments.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    EmptyStateWidget(
                        icon = Icons.Default.History,
                        message = "لا توجد دفعات مسجلة للمشروع حتى الآن."
                    )
                }
            }
        } else {
            items(payments, key = { it.id }) { pay ->
                val sdf = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault())
                val payDate = sdf.format(Date(pay.date))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "+ " + viewModel.formatCurrency(pay.amount),
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = Color(0xFF4CAF50))
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "البيان: ${pay.notes.ifEmpty { "دفعة نقدية" }}",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                            )
                            Text(
                                text = payDate,
                                style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                            )
                        }

                        IconButton(onClick = { onDeletePayment(pay.id) }) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "حذف",
                                tint = Color(0xFFE53935).copy(alpha = 0.8f)
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// Sub-Tab 4: Professional Invoice View (الفاتورة)
// ==========================================
fun generateAndPrintPdf(
    context: android.content.Context,
    project: Project,
    measurements: List<Measurement>,
    materials: List<MaterialCost>,
    payments: List<Payment>,
    viewModel: CarpenterViewModel
) {
    val printManager = context.getSystemService(android.content.Context.PRINT_SERVICE) as android.print.PrintManager
    val jobName = "${project.projectName} - ${project.clientName}"

    // Prepare Workshop details
    val workshopName = viewModel.workshopName.ifEmpty { "ورشة النجارة الذكية الاحترافية" }
    val workshopPhone = viewModel.workshopPhone.ifEmpty { "غير متوفر" }
    val workshopAddress = viewModel.workshopAddress.ifEmpty { "غير متوفر" }

    // Let's encode workshop logo as base64 if it exists
    var logoHtml = ""
    val logoFile = File(viewModel.workshopLogoPath)
    if (logoFile.exists()) {
        try {
            val bitmap = BitmapFactory.decodeFile(logoFile.absolutePath)
            if (bitmap != null) {
                val outputStream = ByteArrayOutputStream()
                bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 80, outputStream)
                val base64 = Base64.encodeToString(outputStream.toByteArray(), Base64.DEFAULT)
                logoHtml = "<img src=\"data:image/png;base64,$base64\" style=\"width: 80px; height: 80px; border-radius: 50%; border: 1px solid #333; margin-bottom: 10px;\" />"
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // Build HTML report
    val remainingBalance = project.finalPrice - project.depositPaid
    val sdf = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault())
    val invoiceDate = sdf.format(Date())

    val htmlContent = """
        <!DOCTYPE html>
        <html dir="rtl" lang="ar">
        <head>
            <meta charset="UTF-8">
            <style>
                body {
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    padding: 20px;
                    color: #333;
                    background-color: #fff;
                }
                .header-container {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    border-bottom: 3px solid #795548;
                    padding-bottom: 15px;
                    margin-bottom: 25px;
                }
                .workshop-info {
                    text-align: right;
                    flex: 1;
                }
                .workshop-title {
                    font-size: 24px;
                    font-weight: bold;
                    color: #795548;
                    margin: 0 0 5px 0;
                }
                .workshop-sub {
                    font-size: 14px;
                    color: #555;
                    margin: 0;
                }
                .logo-container {
                    text-align: left;
                    margin-right: 20px;
                }
                .invoice-title-box {
                    text-align: center;
                    margin-bottom: 30px;
                }
                .invoice-title {
                    font-size: 22px;
                    font-weight: bold;
                    text-decoration: underline;
                    color: #795548;
                }
                .info-grid {
                    width: 100%;
                    border-collapse: collapse;
                    margin-bottom: 25px;
                }
                .info-grid td {
                    padding: 8px;
                    font-size: 15px;
                    border: 1px solid #e0e0e0;
                }
                .info-label {
                    font-weight: bold;
                    background-color: #f5f5f5;
                    width: 20%;
                }
                .section-title {
                    font-size: 18px;
                    font-weight: bold;
                    color: #795548;
                    border-right: 4px solid #795548;
                    padding-right: 10px;
                    margin: 25px 0 12px 0;
                }
                .data-table {
                    width: 100%;
                    border-collapse: collapse;
                    margin-bottom: 25px;
                }
                .data-table th {
                    background-color: #795548;
                    color: #ffffff;
                    font-weight: bold;
                    padding: 10px;
                    font-size: 14px;
                    border: 1px solid #795548;
                }
                .data-table td {
                    padding: 10px;
                    font-size: 14px;
                    border: 1px solid #e0e0e0;
                    text-align: center;
                }
                .data-table tr:nth-child(even) {
                    background-color: #f9f9f9;
                }
                .financial-box {
                    width: 50%;
                    margin-right: auto;
                    border-collapse: collapse;
                    margin-top: 20px;
                }
                .financial-box td {
                    padding: 10px;
                    font-size: 16px;
                    border: 1px solid #e0e0e0;
                }
                .financial-total {
                    font-weight: bold;
                    color: #795548;
                    background-color: #f5f5f5;
                }
                .financial-paid {
                    font-weight: bold;
                    color: #2e7d32;
                    background-color: #e8f5e9;
                }
                .financial-remaining {
                    font-weight: bold;
                    color: #c62828;
                    background-color: #ffebee;
                }
                .footer-text {
                    text-align: center;
                    font-size: 11px;
                    color: #777;
                    margin-top: 50px;
                    border-top: 1px solid #e0e0e0;
                    padding-top: 15px;
                }
            </style>
        </head>
        <body>
            <div class="header-container">
                <div class="workshop-info">
                    <h1 class="workshop-title">$workshopName</h1>
                    <p class="workshop-sub">هاتف: $workshopPhone | العنوان: $workshopAddress</p>
                </div>
                <div class="logo-container">
                    $logoHtml
                </div>
            </div>

            <div class="invoice-title-box">
                <span class="invoice-title">فاتورة تصفية وعرض سعر اتفاق</span>
            </div>

            <table class="info-grid">
                <tr>
                    <td class="info-label">اسم العميل</td>
                    <td>${project.clientName}</td>
                    <td class="info-label">رقم الهاتف</td>
                    <td>${project.clientPhone}</td>
                </tr>
                <tr>
                    <td class="info-label">اسم المشروع</td>
                    <td>${project.projectName}</td>
                    <td class="info-label">تاريخ الفاتورة</td>
                    <td>$invoiceDate</td>
                </tr>
            </table>

            <div class="section-title">أولاً: بيان مقاسات التفصيل والقطع</div>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>م</th>
                        <th>اسم العنصر / القطعة</th>
                        <th>الارتفاع (سم)</th>
                        <th>العرض (سم)</th>
                        <th>العمق (سم)</th>
                        <th>الملاحظات</th>
                    </tr>
                </thead>
                <tbody>
                    ${
                        if (measurements.isEmpty()) {
                            "<tr><td colspan=\"6\">لا توجد مقاسات مسجلة</td></tr>"
                        } else {
                            measurements.mapIndexed { index, m ->
                                """
                                <tr>
                                    <td>${index + 1}</td>
                                    <td>${m.itemName}</td>
                                    <td>${m.height}</td>
                                    <td>${m.width}</td>
                                    <td>${m.depth}</td>
                                    <td>${m.notes.ifEmpty { "جاهز" }}</td>
                                </tr>
                                """.trimIndent()
                            }.joinToString("")
                        }
                    }
                </tbody>
            </table>

            <div class="section-title">ثانياً: الحساب والمستحقات المالية للاتفاق الكلي</div>
            <table class="financial-box">
                <tr class="financial-total">
                    <td>إجمالي قيمة العقد المتفق عليه</td>
                    <td>${viewModel.formatCurrency(project.finalPrice)}</td>
                </tr>
                <tr class="financial-paid">
                    <td>المدفوع المقبوض (المقدم)</td>
                    <td>- ${viewModel.formatCurrency(project.depositPaid)}</td>
                </tr>
                <tr class="financial-remaining">
                    <td>المتبقي للاستلام النهائي</td>
                    <td>${viewModel.formatCurrency(maxOf(0.0, remainingBalance))}</td>
                </tr>
            </table>

            <div class="footer-text">
                هذه الفاتورة مستخرجة رقمياً عبر تطبيق مساعد النجار الذكي ولا تتطلب توقيعاً يدوياً إلا للضرورة.<br>
                نشكركم على ثقتكم الغالية بورشة $workshopName
            </div>
        </body>
        </html>
    """.trimIndent()

    val webView = WebView(context)
    webView.webViewClient = object : WebViewClient() {
        override fun onPageFinished(view: WebView?, url: String?) {
            val printAdapter = webView.createPrintDocumentAdapter(jobName)
            printManager.print(
                jobName,
                printAdapter,
                PrintAttributes.Builder().build()
            )
        }
    }
    webView.loadDataWithBaseURL(null, htmlContent, "text/html", "utf-8", null)
}

@Composable
fun InvoiceTab(
    project: Project,
    measurements: List<Measurement>,
    materials: List<MaterialCost>,
    payments: List<Payment>,
    viewModel: CarpenterViewModel
) {
    val context = LocalContext.current
    val totalCost = materials.sumOf { it.unitCost * it.quantity }
    val remainingBalance = project.finalPrice - project.depositPaid

    // Workshop Profile logo loading for preview
    val logoFile = remember(viewModel.workshopLogoPath) { File(viewModel.workshopLogoPath) }
    val logoBitmap = remember(logoFile) {
        if (logoFile.exists()) {
            try {
                BitmapFactory.decodeFile(logoFile.absolutePath)?.asImageBitmap()
            } catch (e: Exception) {
                null
            }
        } else {
            null
        }
    }

    // Format Share Message
    val formattedShareMessage = remember(project, measurements, materials, payments) {
        val build = StringBuilder()
        build.append("✨ *فاتورة وعرض سعر - ${viewModel.workshopName.ifEmpty { "ورشة النجارة الذكية" }}* ✨\n\n")
        build.append("📂 *تفاصيل المشروع:*\n")
        build.append("• المشروع: ${project.projectName}\n")
        build.append("• العميل الكريم: ${project.clientName}\n")
        build.append("• رقم الجوال: ${project.clientPhone}\n")

        val sdf = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault())
        if (project.deliveryDate > 0) {
            build.append("• موعد التسليم: ${sdf.format(Date(project.deliveryDate))}\n")
        }
        build.append("\n📏 *جدول القياسات التفصيلي:*\n")
        if (measurements.isEmpty()) {
            build.append("لا توجد قياسات مسجلة.\n")
        } else {
            measurements.forEach { m ->
                build.append("- ${m.itemName}: ${m.height}×${m.width}×${m.depth} سم\n")
            }
        }

        build.append("\n💰 *الحساب والتكاليف الكلية:*\n")
        build.append("• سعر الاتفاق النهائي: ${viewModel.formatCurrency(project.finalPrice)}\n")
        build.append("• إجمالي المقبوض (المقدم): ${viewModel.formatCurrency(project.depositPaid)}\n")
        build.append("• المتبقي عند الاستلام: ${viewModel.formatCurrency(maxOf(0.0, remainingBalance))}\n\n")
        build.append("📝 *ملاحظات الورشة:* ${project.notes.ifEmpty { "لا يوجد" }}\n\n")
        build.append("🤝 *شكراً لتعاملكم معنا ونعدكم بأفضل جودة وإتقان!*")
        build.toString()
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // PDF Receipt Mockup Screen
        item {
            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(2.dp, Color.Black),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp)
                        .background(Color.White)
                ) {
                    // Receipt Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = viewModel.workshopName.ifEmpty { "ورشة النجارة الذكية الاحترافية" },
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.Black
                                )
                            )
                            Text(
                                text = "الهاتف: ${viewModel.workshopPhone.ifEmpty { "غير متوفر" }} | العنوان: ${viewModel.workshopAddress.ifEmpty { "غير متوفر" }}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color.Gray,
                                    fontSize = 10.sp
                                )
                            )
                        }
                        
                        if (logoBitmap != null) {
                            Spacer(modifier = Modifier.width(8.dp))
                            Image(
                                bitmap = logoBitmap,
                                contentDescription = "الشعار",
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .border(1.dp, Color.Black, CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .border(2.dp, Color(0xFF3F51B5), RoundedCornerShape(8.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "النجار الذكي\nمعتمد",
                                    color = Color(0xFF3F51B5),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color.Black))
                    Spacer(modifier = Modifier.height(16.dp))

                    // Client details
                    Text(text = "فاتورة تصفية وعرض سعر اتفاق", fontWeight = FontWeight.Bold, textDecoration = TextDecoration.Underline, color = Color.Black, style = MaterialTheme.typography.bodyLarge)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "اسم العميل: ${project.clientName}", color = Color.Black, style = MaterialTheme.typography.bodyMedium)
                    Text(text = "رقم الهاتف: ${project.clientPhone}", color = Color.Black, style = MaterialTheme.typography.bodyMedium)
                    Text(text = "اسم المشروع: ${project.projectName}", color = Color.Black, style = MaterialTheme.typography.bodyMedium)
                    val sdf = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault())
                    Text(text = "تاريخ الفاتورة: ${sdf.format(Date())}", color = Color.Black, style = MaterialTheme.typography.bodyMedium)

                    Spacer(modifier = Modifier.height(16.dp))
                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color.LightGray))
                    Spacer(modifier = Modifier.height(12.dp))

                    // Measurements Table in invoice
                    Text(text = "أولاً: بيان مقاسات التفصيل", fontWeight = FontWeight.Bold, color = Color.Black, style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(6.dp))
                    if (measurements.isEmpty()) {
                        Text(text = "لا توجد مقاسات مسجلة", color = Color.DarkGray, style = MaterialTheme.typography.bodySmall)
                    } else {
                        measurements.forEach { m ->
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "• ${m.itemName}", color = Color.Black, style = MaterialTheme.typography.bodyMedium)
                                Text(text = "${m.height} × ${m.width} × ${m.depth} سم", color = Color.Black, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color.LightGray))
                    Spacer(modifier = Modifier.height(12.dp))

                    // Financial calculations
                    Text(text = "ثانياً: الحساب والمستحقات والاتفاق الكلي", fontWeight = FontWeight.Bold, color = Color.Black, style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "إجمالي قيمة العقد المتفق عليه:", color = Color.Black, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold))
                        Text(text = viewModel.formatCurrency(project.finalPrice), color = Color.Black, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold))
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "المدفوع المقبوض (المقدم):", color = Color(0xFF4CAF50), style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                        Text(text = "- " + viewModel.formatCurrency(project.depositPaid), color = Color(0xFF4CAF50), style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color.LightGray))
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "المتبقي للاستلام النهائي:", color = Color(0xFFE53935), style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.ExtraBold))
                        Text(text = viewModel.formatCurrency(maxOf(0.0, remainingBalance)), color = Color(0xFFE53935), style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.ExtraBold))
                    }

                    Spacer(modifier = Modifier.height(24.dp))
                    Text(
                        text = "هذه الفاتورة مستخرجة رقمياً عبر تطبيق مساعد النجار الذكي ولا تتطلب توقيع يدوي إلا للضرورة.",
                        style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray, fontSize = 9.sp, textAlign = TextAlign.Center),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Print PDF Button
        item {
            Button(
                onClick = {
                    generateAndPrintPdf(context, project, measurements, materials, payments, viewModel)
                },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp)
            ) {
                Icon(imageVector = Icons.Default.PictureAsPdf, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("توليد وطباعة فاتورة PDF رسمي 📄")
            }
        }

        // Sharing Button
        item {
            OutlinedButton(
                onClick = {
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, formattedShareMessage)
                    }
                    context.startActivity(Intent.createChooser(shareIntent, "مشاركة تفاصيل الفاتورة نصياً"))
                },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = Color(0xFF25D366) // WhatsApp Green
                ),
                border = BorderStroke(1.dp, Color(0xFF25D366)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp)
            ) {
                Icon(imageVector = Icons.Default.Share, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("مشاركة تفاصيل الفاتورة نصياً")
            }
        }
    }
}

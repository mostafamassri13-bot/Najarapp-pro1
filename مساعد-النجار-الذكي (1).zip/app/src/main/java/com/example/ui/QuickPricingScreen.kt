package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.*
import com.example.data.WoodPanel

data class ProjectPiece(
    val id: String = java.util.UUID.randomUUID().toString(),
    val name: String,
    val length: Double,
    val width: Double,
    val quantity: Int
)

@Composable
fun QuickPricingScreen(
    viewModel: CarpenterViewModel,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(0) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // App Header
        AppHeader(
            title = "التسعير والتحليل المالي 💰",
            subtitle = "حساب عروض الأسعار الفورية، تكاليف الألواح، وتأمين هوامش الأرباح",
            actions = {
                var showCurrencyDialog by remember { mutableStateOf(false) }
                IconButton(
                    onClick = { showCurrencyDialog = true },
                    modifier = Modifier
                        .background(
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                            shape = RoundedCornerShape(8.dp)
                        )
                ) {
                    Icon(
                        imageVector = Icons.Default.Paid,
                        contentDescription = "إعدادات العملة",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }

                if (showCurrencyDialog) {
                    CurrencySettingsDialog(
                        viewModel = viewModel,
                        onDismiss = { showCurrencyDialog = false }
                    )
                }
            }
        )

        // Tab Row
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.primary,
            modifier = Modifier.fillMaxWidth()
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("تسعير المواد واليد 💰", fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("حاسبة الألواح والمشروع 🪵", fontWeight = FontWeight.Bold) }
            )
        }

        if (selectedTab == 0) {
            RawMaterialsPricingTab(viewModel = viewModel, modifier = Modifier.weight(1f))
        } else {
            WoodPanelsCalculatorTab(viewModel = viewModel, modifier = Modifier.weight(1f))
        }
    }
}

@Composable
fun RawMaterialsPricingTab(
    viewModel: CarpenterViewModel,
    modifier: Modifier = Modifier
) {
    var materialName by remember { mutableStateOf("") }
    var unitType by remember { mutableStateOf("لوح") }
    var unitCost by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("") }

    val pricingResult = viewModel.getQuickPricingResult()

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Temporary Material Input Form
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "أضف مادة خام للتسعير السريع:",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = materialName,
                        onValueChange = { materialName = it },
                        label = { Text("اسم المادة (مثال: رخام، مقبض، لوح MDF)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        var expanded by remember { mutableStateOf(false) }
                        Box(modifier = Modifier.weight(1.2f)) {
                            OutlinedTextField(
                                value = unitType,
                                onValueChange = {},
                                label = { Text("الوحدة") },
                                readOnly = true,
                                trailingIcon = {
                                    IconButton(onClick = { expanded = !expanded }) {
                                        Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null)
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            )
                            DropdownMenu(
                                expanded = expanded,
                                onDismissRequest = { expanded = false }
                            ) {
                                listOf("لوح", "متر مربع", "متر طولي", "حبة", "طقم", "كيس", "أخرى").forEach { option ->
                                    DropdownMenuItem(
                                        text = { Text(option) },
                                        onClick = {
                                            unitType = option
                                            expanded = false
                                        }
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = unitCost,
                            onValueChange = { unitCost = it },
                            label = { Text("سعر الوحدة (${viewModel.selectedCurrency.symbol})") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1.1f),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )

                        OutlinedTextField(
                            value = quantity,
                            onValueChange = { quantity = it },
                            label = { Text("الكمية") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            val cost = unitCost.toDoubleOrNull() ?: 0.0
                            val qty = quantity.toDoubleOrNull() ?: 0.0
                            if (materialName.isNotBlank() && cost > 0 && qty > 0) {
                                viewModel.addQuickPricingItem(materialName, cost, qty, unitType)
                                materialName = ""
                                unitCost = ""
                                quantity = ""
                            }
                        },
                        enabled = materialName.isNotBlank() && unitCost.isNotBlank() && quantity.isNotBlank(),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("إضافة المادة")
                    }
                }
            }
        }

        // Pricing Config (Labor only, Profit margin removed)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "تكلفة المصنعية / أجر اليد:",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = viewModel.quickPricingLaborCost,
                        onValueChange = { viewModel.quickPricingLaborCost = it },
                        label = { Text("أجر اليد / المصنعية (${viewModel.selectedCurrency.symbol})") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }
        }

        // List of pricing materials
        if (viewModel.quickPricingItems.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "المواد المضافة للتسعير:", fontWeight = FontWeight.Bold)
                    TextButton(onClick = { viewModel.clearQuickPricing() }) {
                        Icon(imageVector = Icons.Default.DeleteSweep, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("تفريغ الحاسبة", color = Color(0xFFE53935))
                    }
                }
            }

            items(viewModel.quickPricingItems, key = { it.id }) { item ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = item.name, fontWeight = FontWeight.Bold)
                            Text(
                                text = "الكمية: ${item.quantity} ${item.unitType} × ${viewModel.formatCurrency(item.unitCost)}",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = viewModel.formatCurrency(item.unitCost * item.quantity),
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            IconButton(onClick = { viewModel.removeQuickPricingItem(item.id) }) {
                                Icon(imageVector = Icons.Default.Delete, contentDescription = "حذف", tint = Color(0xFFE53935).copy(alpha = 0.8f))
                            }
                        }
                    }
                }
            }
        }

        // Live calculation card (الميزانية المباشرة والربح)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)),
                border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "فاتورة الحساب التقديرية 🧾",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("إجمالي المواد الخام:", style = MaterialTheme.typography.bodyMedium)
                        Text(viewModel.formatCurrency(pricingResult.materialsTotal), style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("تكلفة اليد (المصنعية):", style = MaterialTheme.typography.bodyMedium)
                        Text(viewModel.formatCurrency(pricingResult.laborCost), style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)))
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("السعر النهائي المقترح للزبون:", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        Text(
                            text = viewModel.formatCurrency(pricingResult.finalPrice),
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary, fontSize = 22.sp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun WoodPanelsCalculatorTab(
    viewModel: CarpenterViewModel,
    modifier: Modifier = Modifier
) {
    val woodPanels by viewModel.woodPanels.collectAsState()
    var selectedPanel by remember { mutableStateOf<WoodPanel?>(null) }

    // Required pieces local state
    val projectPieces = remember { mutableStateListOf<ProjectPiece>() }

    // Input States for New Project Piece
    var pieceName by remember { mutableStateOf("") }
    var pieceLengthStr by remember { mutableStateOf("") }
    var pieceWidthStr by remember { mutableStateOf("") }
    var pieceQuantityStr by remember { mutableStateOf("1") }

    // Input States for Adding Board to Database (Inventory management)
    var isInventoryExpanded by remember { mutableStateOf(false) }
    var boardName by remember { mutableStateOf("") }
    var boardLengthStr by remember { mutableStateOf("") }
    var boardWidthStr by remember { mutableStateOf("") }
    var boardPriceStr by remember { mutableStateOf("") }

    // Keep selected panel sync'd with changes
    LaunchedEffect(woodPanels) {
        if (selectedPanel == null && woodPanels.isNotEmpty()) {
            selectedPanel = woodPanels.first()
        } else if (selectedPanel != null && !woodPanels.any { it.id == selectedPanel!!.id }) {
            selectedPanel = woodPanels.firstOrNull()
        } else if (selectedPanel != null) {
            // Update to have matching latest object
            selectedPanel = woodPanels.firstOrNull { it.id == selectedPanel!!.id }
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 90.dp, top = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Section 1: Wood Panel Selection Dropdown
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Layers,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "اختر لوح الخشب المطلوب من المخزن 🪵",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))

                    var dropdownExpanded by remember { mutableStateOf(false) }
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = selectedPanel?.name ?: "يرجى اختيار لوح خشب...",
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = {
                                IconButton(onClick = { dropdownExpanded = !dropdownExpanded }) {
                                    Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null)
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { dropdownExpanded = !dropdownExpanded },
                            shape = RoundedCornerShape(10.dp)
                        )
                        DropdownMenu(
                            expanded = dropdownExpanded,
                            onDismissRequest = { dropdownExpanded = false },
                            modifier = Modifier.fillMaxWidth(0.9f)
                        ) {
                            if (woodPanels.isEmpty()) {
                                DropdownMenuItem(
                                    text = { Text("لا توجد ألواح بالمخزن، يرجى إضافتها بالأسفل") },
                                    onClick = { dropdownExpanded = false }
                                )
                            } else {
                                woodPanels.forEach { panel ->
                                    val activePrice = when (viewModel.selectedCurrency) {
                                        AppCurrency.USD -> panel.price
                                        AppCurrency.SYP -> panel.price * viewModel.usdToSypRate
                                        AppCurrency.SAR -> panel.price * viewModel.usdToSarRate
                                    }
                                    DropdownMenuItem(
                                        text = {
                                            Text("${panel.name} (${panel.length}×${panel.width} سم) - ${viewModel.formatCurrency(panel.price)}")
                                        },
                                        onClick = {
                                            selectedPanel = panel
                                            dropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    if (selectedPanel != null) {
                        Spacer(modifier = Modifier.height(16.dp))

                        val panel = selectedPanel!!
                        val boardArea = (panel.length / 100.0) * (panel.width / 100.0)
                        val boardPricePerSqM = panel.price / boardArea

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f)),
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text("أبعاد اللوح", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text("${panel.length} × ${panel.width} سم", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                            }

                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f),
                                    contentColor = MaterialTheme.colorScheme.onSurface
                                ),
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text("المساحة الإجمالية", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(String.format(Locale.US, "%.2f م²", boardArea), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                            }

                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f),
                                    contentColor = MaterialTheme.colorScheme.onSurface
                                ),
                                modifier = Modifier.weight(1.2f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text("سعر المتر المربع", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(viewModel.formatCurrency(boardPricePerSqM), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    } else {
                        Spacer(modifier = Modifier.height(12.dp))
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                                Text(
                                    text = "يرجى اختيار أو تسجيل لوح خشب كامل من المخزن أدناه للتمكن من حساب تكلفة المشروع.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                            }
                        }
                    }
                }
            }
        }

        // Section 2: Manage Panels Inventory 📦 (Expandable Form & List inside Calculator)
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isInventoryExpanded = !isInventoryExpanded },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Inventory,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "إدارة المخزن وتسجيل الألواح 📦",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Icon(
                            imageVector = if (isInventoryExpanded) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    if (isInventoryExpanded) {
                        Spacer(modifier = Modifier.height(16.dp))

                        OutlinedTextField(
                            value = boardName,
                            onValueChange = { boardName = it },
                            label = { Text("اسم لوح الخشب (مثال: MDF 18mm أبيض)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = boardLengthStr,
                                onValueChange = { boardLengthStr = it },
                                label = { Text("الطول (سم)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1.0f),
                                singleLine = true,
                                shape = RoundedCornerShape(10.dp)
                            )

                            OutlinedTextField(
                                value = boardWidthStr,
                                onValueChange = { boardWidthStr = it },
                                label = { Text("العرض (سم)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1.0f),
                                singleLine = true,
                                shape = RoundedCornerShape(10.dp)
                            )

                            OutlinedTextField(
                                value = boardPriceStr,
                                onValueChange = { boardPriceStr = it },
                                label = { Text("سعر اللوح الكامل") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1.2f),
                                singleLine = true,
                                shape = RoundedCornerShape(10.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                val length = boardLengthStr.toDoubleOrNull() ?: 0.0
                                val width = boardWidthStr.toDoubleOrNull() ?: 0.0
                                val price = boardPriceStr.toDoubleOrNull() ?: 0.0
                                if (boardName.isNotBlank() && length > 0 && width > 0 && price > 0) {
                                    viewModel.addWoodPanel(boardName, length, width, price)
                                    boardName = ""
                                    boardLengthStr = ""
                                    boardWidthStr = ""
                                    boardPriceStr = ""
                                }
                            },
                            enabled = boardName.isNotBlank() && boardLengthStr.isNotBlank() && boardWidthStr.isNotBlank() && boardPriceStr.isNotBlank(),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.Save, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("حفظ اللوح محلياً بقاعدة البيانات")
                        }

                        // Local show of existing panels
                        if (woodPanels.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "الألواح المسجلة بالمخزن (${woodPanels.size}):",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                woodPanels.take(5).forEach { panel ->
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(8.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(text = panel.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                                Text(
                                                    text = "${panel.length} × ${panel.width} سم | ${viewModel.formatCurrency(panel.price)}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                                )
                                            }
                                            IconButton(
                                                onClick = { viewModel.deleteWoodPanel(panel.id) },
                                                modifier = Modifier.size(36.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Delete,
                                                    contentDescription = "حذف اللوح",
                                                    tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f),
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                                if (woodPanels.size > 5) {
                                    Text(
                                        text = "تعديل وحذف باقي الألواح متاح بالكامل في تبويب 'قاعدة الخامات' بالإعدادات.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section 3: Add Cut Pieces required for the project 📐
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.SquareFoot,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "إدخال قياسات القطع المطلوبة للمشروع 📐",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = pieceName,
                        onValueChange = { pieceName = it },
                        label = { Text("اسم القطعة (مثال: رف علوي، باب خزانة، قاطع)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = pieceLengthStr,
                            onValueChange = { pieceLengthStr = it },
                            label = { Text("الطول (سم)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )

                        OutlinedTextField(
                            value = pieceWidthStr,
                            onValueChange = { pieceWidthStr = it },
                            label = { Text("العرض (سم)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )

                        OutlinedTextField(
                            value = pieceQuantityStr,
                            onValueChange = { pieceQuantityStr = it },
                            label = { Text("العدد") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(0.8f),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            val length = pieceLengthStr.toDoubleOrNull() ?: 0.0
                            val width = pieceWidthStr.toDoubleOrNull() ?: 0.0
                            val qty = pieceQuantityStr.toIntOrNull() ?: 1
                            if (length > 0 && width > 0 && qty > 0) {
                                val cleanName = if (pieceName.isBlank()) "قطعة مشروع" else pieceName
                                projectPieces.add(
                                    ProjectPiece(
                                        name = cleanName,
                                        length = length,
                                        width = width,
                                        quantity = qty
                                    )
                                )
                                pieceName = ""
                                pieceLengthStr = ""
                                pieceWidthStr = ""
                                pieceQuantityStr = "1"
                            }
                        },
                        enabled = pieceLengthStr.isNotBlank() && pieceWidthStr.isNotBlank() && pieceQuantityStr.isNotBlank(),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("إضافة القطعة للقائمة")
                    }
                }
            }
        }

        // Section 4: Display Project Pieces List
        if (projectPieces.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "قطع خشب المشروع المضافة:",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    TextButton(onClick = { projectPieces.clear() }) {
                        Icon(imageVector = Icons.Default.DeleteSweep, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("حذف جميع القطع", color = Color(0xFFE53935))
                    }
                }
            }

            items(projectPieces, key = { it.id }) { piece ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1.3f)) {
                            Text(text = piece.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text(
                                text = "القياس: ${piece.length} × ${piece.width} سم | العدد: ${piece.quantity}",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                            )
                            Text(
                                text = String.format(Locale.US, "إجمالي المساحة: %.3f م²", (piece.length / 100.0) * (piece.width / 100.0) * piece.quantity),
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            if (selectedPanel != null) {
                                val boardArea = (selectedPanel!!.length / 100.0) * (selectedPanel!!.width / 100.0)
                                val boardPricePerSqM = selectedPanel!!.price / boardArea
                                val pieceAreaSqM = (piece.length / 100.0) * (piece.width / 100.0) * piece.quantity
                                val estimatedCost = pieceAreaSqM * boardPricePerSqM

                                Text(
                                    text = viewModel.formatCurrency(estimatedCost),
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.weight(1f),
                                    textAlign = TextAlign.End
                                )
                            } else {
                                Spacer(modifier = Modifier.weight(1f))
                            }

                            IconButton(onClick = { projectPieces.remove(piece) }) {
                                Icon(imageVector = Icons.Default.Delete, contentDescription = "حذف القطعة", tint = Color(0xFFE53935).copy(alpha = 0.8f))
                            }
                        }
                    }
                }
            }
        }

        // Section 5: Estimated Calculations and Analytics Card
        item {
            val totalRequiredAreaSqM = projectPieces.sumOf { (it.length / 100.0) * (it.width / 100.0) * it.quantity }
            val boardArea = selectedPanel?.let { (it.length / 100.0) * (it.width / 100.0) } ?: 1.0
            val boardPricePerSqM = selectedPanel?.let { it.price / boardArea } ?: 0.0
            val totalEstimatedCostBase = totalRequiredAreaSqM * boardPricePerSqM

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)),
                border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "تقرير التكلفة الإجمالية للألواح 📐🧾",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("اللوح المستهدف للتسعير:", style = MaterialTheme.typography.bodyMedium)
                        Text(selectedPanel?.name ?: "لم يتم الاختيار", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("إجمالي مساحة قطع المشروع:", style = MaterialTheme.typography.bodyMedium)
                        Text(String.format(Locale.US, "%.3f م²", totalRequiredAreaSqM), style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("سعر المتر المربع للوح:", style = MaterialTheme.typography.bodyMedium)
                        Text(viewModel.formatCurrency(boardPricePerSqM), style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)))
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("التكلفة المباشرة (مساحة صافية):", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        Text(
                            text = viewModel.formatCurrency(totalEstimatedCostBase),
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary, fontSize = 22.sp)
                        )
                    }

                    if (selectedPanel != null && totalRequiredAreaSqM > 0) {
                        Spacer(modifier = Modifier.height(14.dp))
                        val sheetsNeeded = totalRequiredAreaSqM / boardArea
                        val exactSheetsRounded = kotlin.math.ceil(sheetsNeeded).toInt()

                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.6f)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = String.format(
                                        Locale.getDefault(),
                                        "💡 تحتاج نظرياً إلى %.2f لوح كامل.",
                                        sheetsNeeded
                                    ),
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.fillMaxWidth(),
                                    textAlign = TextAlign.Right
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = String.format(
                                        Locale.getDefault(),
                                        "الحد الأدنى للشراء الفعلي من السوق هو %d ألواح كاملة.\nالتكلفة التقديرية للألواح الكاملة: %s",
                                        exactSheetsRounded,
                                        viewModel.formatCurrency(exactSheetsRounded * selectedPanel!!.price)
                                    ),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.fillMaxWidth(),
                                    textAlign = TextAlign.Right
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

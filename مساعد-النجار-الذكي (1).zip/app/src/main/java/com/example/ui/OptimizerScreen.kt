package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.Measurement
import com.example.data.BoardType
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OptimizerScreen(
    viewModel: CarpenterViewModel,
    modifier: Modifier = Modifier
) {
    val project by viewModel.currentProject.collectAsState()
    val measurements by viewModel.currentMeasurements.collectAsState()
    val standardBoards by viewModel.standardBoards.collectAsState()
    val optResult = viewModel.optimizerResult

    var showAddItemDialog by remember { mutableStateOf(false) }
    var dropdownExpanded by remember { mutableStateOf(false) }
    var selectedBoard by remember { mutableStateOf<BoardType?>(null) }

    LaunchedEffect(viewModel.sheetWidthInput, viewModel.sheetHeightInput, standardBoards) {
        selectedBoard = standardBoards.find {
            it.width.toString() == viewModel.sheetWidthInput && it.length.toString() == viewModel.sheetHeightInput
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // App Header
        item {
            AppHeader(
                title = "مخطط القص الذكي 📏",
                subtitle = "حساب القص والتخطيط لتقليل الهدر المادي للألواح"
            )
        }

        // Board Config Inputs
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "أبعاد اللوح الأساسي وشفرة القص 🪵",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = selectedBoard?.let { "${it.name} (${it.width} × ${it.length} سم) - ${viewModel.formatCurrency(it.price)}" }
                                ?: if (viewModel.sheetWidthInput.isNotEmpty() && viewModel.sheetHeightInput.isNotEmpty())
                                    "لوح مخصص (${viewModel.sheetWidthInput} × ${viewModel.sheetHeightInput} سم)"
                                   else "اختر لوح خشب من المخزن...",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("لوح الخشب المختار 🪵") },
                            trailingIcon = {
                                IconButton(onClick = { dropdownExpanded = !dropdownExpanded }) {
                                    Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null)
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { dropdownExpanded = !dropdownExpanded },
                            shape = RoundedCornerShape(10.dp)
                        )
                        DropdownMenu(
                            expanded = dropdownExpanded,
                            onDismissRequest = { dropdownExpanded = false },
                            modifier = Modifier.fillMaxWidth(0.9f)
                        ) {
                            if (standardBoards.isEmpty()) {
                                DropdownMenuItem(
                                    text = { Text("لا توجد ألواح ستاندر بالمخزن، يرجى إضافتها بالإعدادات") },
                                    onClick = { dropdownExpanded = false }
                                )
                            } else {
                                standardBoards.forEach { board ->
                                    DropdownMenuItem(
                                        text = {
                                            Text("${board.name} (${board.width} × ${board.length} سم) - ${viewModel.formatCurrency(board.price)}")
                                        },
                                        onClick = {
                                            selectedBoard = board
                                            viewModel.updateSheetDimensions(
                                                board.width.toString(),
                                                board.length.toString(),
                                                viewModel.sawKerfInput,
                                                viewModel.allowRotationInput
                                            )
                                            dropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = viewModel.sheetWidthInput,
                            onValueChange = {
                                viewModel.sheetWidthInput = it
                                viewModel.runOptimization()
                            },
                            label = { Text("عرض اللوح (سم)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )
                        OutlinedTextField(
                            value = viewModel.sheetHeightInput,
                            onValueChange = {
                                viewModel.sheetHeightInput = it
                                viewModel.runOptimization()
                            },
                            label = { Text("طول اللوح (سم)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )
                        OutlinedTextField(
                            value = viewModel.sawKerfInput,
                            onValueChange = {
                                viewModel.sawKerfInput = it
                                viewModel.runOptimization()
                            },
                            label = { Text("سماكة شفرة القص (سم)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = viewModel.allowRotationInput,
                                onCheckedChange = {
                                    viewModel.allowRotationInput = it
                                    viewModel.runOptimization()
                                }
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "السماح بتدوير القطع لتوفير المساحة",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }

                    // Quick-fill buttons for common standard sheet sizes
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "مقاسات شائعة بالورش:",
                        style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            "لوح MDF قياسي (122×244)" to Pair("122.0", "244.0"),
                            "لوح MDF كبير (183×366)" to Pair("183.0", "366.0"),
                            "صفائح خشب رقائقي (122×122)" to Pair("122.0", "122.0")
                        ).forEach { (label, sizes) ->
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                ),
                                modifier = Modifier
                                    .background(
                                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                                        shape = RoundedCornerShape(6.dp)
                                    )
                                    .clickable {
                                        viewModel.updateSheetDimensions(sizes.first, sizes.second, viewModel.sawKerfInput, viewModel.allowRotationInput)
                                    }
                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                            )
                        }
                    }

                    // Import Project Measurements if any
                    if (project != null && measurements.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = { viewModel.importMeasurementsToOptimizer() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.secondary,
                                contentColor = MaterialTheme.colorScheme.onSecondary
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.CloudDownload, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("استيراد مقاسات مشروع '${project?.projectName}'")
                        }
                    }
                }
            }
        }

        // Active List & Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "القطع المطلوب قصّها (${viewModel.optimizerItems.sumOf { it.quantity }})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )

                Button(
                    onClick = { showAddItemDialog = true },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("أضف قطعة", fontSize = 12.sp)
                }
            }
        }

        // List of custom cut items
        if (viewModel.optimizerItems.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    EmptyStateWidget(
                        icon = Icons.Default.Inventory,
                        message = "لا توجد قطع مضافة للقص حالياً.\nأضف قطعة يدوياً أو استورد مقاسات المشروع."
                    )
                }
            }
        } else {
            items(viewModel.optimizerItems) { item ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .background(Color(android.graphics.Color.parseColor(item.colorHex)), RoundedCornerShape(6.dp))
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = item.name,
                                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "${item.height} × ${item.width} سم  [العدد: ${item.quantity}]",
                                    style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                                )
                            }
                        }

                        IconButton(onClick = { viewModel.deleteOptimizerItem(item.id) }) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "حذف",
                                tint = Color(0xFFE53935).copy(alpha = 0.8f)
                            )
                        }
                    }
                }
            }
        }

        // Optimization results
        if (optResult != null && viewModel.optimizerItems.isNotEmpty()) {
            // Summary KPI metrics
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                ) {
                    Text(
                        text = "نتائج التخطيط والتحليل الذكي:",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Card(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f))
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("الألواح المطلوبة لشراءها", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                Text("${optResult.totalSheetsUsed} ألواح", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold))
                            }
                        }

                        Card(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (optResult.overallEfficiency > 80.0) Color(0xFF4CAF50).copy(alpha = 0.12f)
                                else Color(0xFFFF9800).copy(alpha = 0.12f)
                            )
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("كفاءة استغلال الخشب", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                                Text(String.format(Locale.US, "%.1f %%", optResult.overallEfficiency), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold))
                            }
                        }

                        Card(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFE53935).copy(alpha = 0.08f))
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("نسبة الهدر المتبقية", style = MaterialTheme.typography.labelSmall, color = Color(0xFFE53935))
                                Text(String.format(Locale.US, "%.1f %%", 100.0 - optResult.overallEfficiency), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold, color = Color(0xFFE53935)))
                            }
                        }
                    }
                }
            }

            // Unplaced items warning
            if (optResult.unplacedItems.isNotEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFE53935).copy(alpha = 0.12f)),
                        border = BorderStroke(1.dp, Color(0xFFE53935).copy(alpha = 0.3f))
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = Color(0xFFE53935))
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text("قطع غير قابلة للوضع! ⚠️", fontWeight = FontWeight.Bold, color = Color(0xFFE53935))
                                optResult.unplacedItems.forEach { uItem ->
                                    Text(
                                        text = "• ${uItem.name} (${uItem.height}×${uItem.width}سم) - تتجاوز مقاسات اللوح الأساسي.",
                                        style = MaterialTheme.typography.bodySmall.copy(color = Color.Black)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Sheet-by-Sheet Drawing Layouts
            items(optResult.sheets, key = { it.sheetIndex }) { sheet ->
                SheetLayoutDrawCard(
                    sheet = sheet,
                    sheetWidth = viewModel.sheetWidthInput.toDoubleOrNull() ?: 122.0,
                    sheetHeight = viewModel.sheetHeightInput.toDoubleOrNull() ?: 244.0
                )
            }
        }
    }

    if (showAddItemDialog) {
        AddCutItemDialog(
            onDismiss = { showAddItemDialog = false },
            onConfirm = { name, w, h, qty, color ->
                viewModel.addOptimizerItem(name, w, h, qty, color)
                showAddItemDialog = false
            }
        )
    }
}

@Composable
fun SheetLayoutDrawCard(
    sheet: com.example.ui.SheetResult,
    sheetWidth: Double,
    sheetHeight: Double
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Board header details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "اللوح الخشبي رقم #${sheet.sheetIndex} 🪵",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = String.format(Locale.US, "الكفاءة: %.1f %%", sheet.efficiencyPercentage),
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = Color(0xFF4CAF50),
                        fontWeight = FontWeight.Bold
                    ),
                    modifier = Modifier
                        .background(Color(0xFF4CAF50).copy(alpha = 0.12f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Dynamic Wood Sheet Drawer Box using Compose absolute positioning!
            // We want to scale the sheet height and width to fit the phone screen aspect ratio
            val aspectRatio = sheetWidth / sheetHeight
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(aspectRatio.toFloat())
                    .background(Color(0xFFF1E9DB), RoundedCornerShape(12.dp)) // Wood Base
                    .border(2.dp, Color(0xFFD2B48C), RoundedCornerShape(12.dp)) // Wood Border
                    .clip(RoundedCornerShape(12.dp))
            ) {
                val containerWidth = maxWidth.value
                val scaleFactor = containerWidth / sheetWidth

                // Draw each placed item as a Box
                sheet.placedItems.forEach { item ->
                    val x = (item.x * scaleFactor).dp
                    val y = (item.y * scaleFactor).dp
                    val itemW = (item.width * scaleFactor).dp
                    val itemH = (item.height * scaleFactor).dp

                    val itemColor = Color(android.graphics.Color.parseColor(item.colorHex))

                    Box(
                        modifier = Modifier
                            .offset(x = x, y = y)
                            .size(width = itemW, height = itemH)
                            .background(
                                color = itemColor.copy(alpha = 0.35f),
                                shape = RoundedCornerShape(4.dp)
                            )
                            .border(1.dp, itemColor.copy(alpha = 0.7f), RoundedCornerShape(4.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier.padding(2.dp)
                        ) {
                            Text(
                                text = item.name,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color(0xFF5D4037),
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = if (itemW.value < 50) 7.sp else 9.sp
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${item.height.toInt()}×${item.width.toInt()}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color(0xFF5D4037).copy(alpha = 0.8f),
                                    fontSize = if (itemW.value < 50) 6.sp else 8.sp
                                ),
                                maxLines = 1
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
            Spacer(modifier = Modifier.height(12.dp))

            // Cutting instructions listing
            Text(
                text = "دليل مخطط قطعيات اللوح #${sheet.sheetIndex}:",
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
            )
            Spacer(modifier = Modifier.height(6.dp))

            sheet.placedItems.forEachIndexed { i, item ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .background(Color(android.graphics.Color.parseColor(item.colorHex)), RoundedCornerShape(3.dp))
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "${i + 1}. قص قطعة '${item.name}'",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    Text(
                        text = "الموقع: [سين: ${item.x.toInt()}، صاد: ${item.y.toInt()}] 📏 المقاس: ${item.height}×${item.width}سم",
                        style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                    )
                }
            }
        }
    }
}

@Composable
fun AddCutItemDialog(
    onDismiss: () -> Unit,
    onConfirm: (name: String, width: Double, height: Double, qty: Int, colorHex: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var width by remember { mutableStateOf("") }
    var height by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("1") }

    val colors = listOf("#4CAF50", "#FFC107", "#2196F3", "#9C27B0", "#E91E63", "#00BCD4", "#FF5722")
    var selectedColor by remember { mutableStateOf(colors.first()) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Text(
                    text = "إضافة قطعة خشب للقص 📏",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Right
                )
                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم الجزء الخشبي (مثال: درفة رف، قاعدة)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = height,
                        onValueChange = { height = it },
                        label = { Text("الارتفاع (سم)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )
                    OutlinedTextField(
                        value = width,
                        onValueChange = { width = it },
                        label = { Text("العرض (سم)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = quantity,
                    onValueChange = { quantity = it },
                    label = { Text("الكمية (العدد المطلوبة)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Color picker
                Text(
                    text = "اختر لون تمييز بصري للقطعة:",
                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Right
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    colors.forEach { colorHex ->
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .background(Color(android.graphics.Color.parseColor(colorHex)), RoundedCornerShape(6.dp))
                                .border(
                                    width = if (selectedColor == colorHex) 2.5.dp else 0.dp,
                                    color = if (selectedColor == colorHex) MaterialTheme.colorScheme.primary else Color.Transparent,
                                    shape = RoundedCornerShape(6.dp)
                                )
                                .clickable { selectedColor = colorHex }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            val w = width.toDoubleOrNull() ?: 0.0
                            val h = height.toDoubleOrNull() ?: 0.0
                            val qty = quantity.toIntOrNull() ?: 1
                            if (name.isNotBlank() && w > 0 && h > 0 && qty > 0) {
                                onConfirm(name, w, h, qty, selectedColor)
                            }
                        },
                        enabled = name.isNotBlank() && width.isNotBlank() && height.isNotBlank(),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1.5f)
                    ) {
                        Text("إضافة")
                    }

                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("إلغاء")
                    }
                }
            }
        }
    }
}

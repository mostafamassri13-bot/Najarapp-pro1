package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Construction
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.AppScreen
import com.example.ui.CarpenterViewModel
import com.example.ui.CarpenterViewModelFactory
import com.example.ui.DashboardScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.OptimizerScreen
import com.example.ui.ProjectDetailsScreen
import com.example.ui.QuickPricingScreen
import com.example.ui.SettingsScreen
import com.example.ui.PinLockScreen
import androidx.compose.material.icons.filled.Settings

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                // Since this app is entirely in Arabic for Arab carpenters,
                // we force the RTL Layout Direction to ensure flawless mirror alignment of Compose widgets!
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    val viewModel: CarpenterViewModel = viewModel(
                        factory = CarpenterViewModelFactory(application)
                    )

                    if (viewModel.isLocked) {
                        PinLockScreen(viewModel = viewModel)
                    } else {
                        Scaffold(
                            bottomBar = {
                                // Only show bottom navigation on primary screens
                                if (viewModel.currentScreen != AppScreen.ProjectDetails) {
                                    NavigationBar(
                                        containerColor = MaterialTheme.colorScheme.surface,
                                        tonalElevation = 0.dp,
                                        modifier = Modifier
                                            .navigationBarsPadding()
                                            .border(BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)))
                                    ) {
                                        NavigationBarItem(
                                            selected = viewModel.currentScreen == AppScreen.Dashboard,
                                            onClick = { viewModel.navigateTo(AppScreen.Dashboard) },
                                            icon = { Icon(imageVector = Icons.Default.Dashboard, contentDescription = "المشاريع") },
                                            label = { Text("المشاريع") },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                                unselectedIconColor = MaterialTheme.colorScheme.secondary,
                                                unselectedTextColor = MaterialTheme.colorScheme.secondary,
                                                indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                                            )
                                        )
                                        NavigationBarItem(
                                            selected = viewModel.currentScreen == AppScreen.Optimizer,
                                            onClick = { viewModel.navigateTo(AppScreen.Optimizer) },
                                            icon = { Icon(imageVector = Icons.Default.GridOn, contentDescription = "قص الألواح") },
                                            label = { Text("قص الألواح") },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                                unselectedIconColor = MaterialTheme.colorScheme.secondary,
                                                unselectedTextColor = MaterialTheme.colorScheme.secondary,
                                                indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                                            )
                                        )
                                        NavigationBarItem(
                                            selected = viewModel.currentScreen == AppScreen.QuickPricing,
                                            onClick = { viewModel.navigateTo(AppScreen.QuickPricing) },
                                            icon = { Icon(imageVector = Icons.Default.Calculate, contentDescription = "التسعير") },
                                            label = { Text("التسعير السريع") },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                                unselectedIconColor = MaterialTheme.colorScheme.secondary,
                                                unselectedTextColor = MaterialTheme.colorScheme.secondary,
                                                indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                                            )
                                        )
                                        NavigationBarItem(
                                            selected = viewModel.currentScreen == AppScreen.Settings,
                                            onClick = { viewModel.navigateTo(AppScreen.Settings) },
                                            icon = { Icon(imageVector = Icons.Default.Settings, contentDescription = "الإعدادات") },
                                            label = { Text("الإعدادات") },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                                unselectedIconColor = MaterialTheme.colorScheme.secondary,
                                                unselectedTextColor = MaterialTheme.colorScheme.secondary,
                                                indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                                            )
                                        )
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxSize()
                        ) { innerPadding ->
                            AnimatedContent(
                                targetState = viewModel.currentScreen,
                                transitionSpec = {
                                    fadeIn().togetherWith(fadeOut())
                                },
                                label = "screen_transition",
                                modifier = Modifier.padding(innerPadding)
                            ) { screen ->
                                when (screen) {
                                    AppScreen.Dashboard -> DashboardScreen(viewModel = viewModel)
                                    AppScreen.ProjectDetails -> ProjectDetailsScreen(viewModel = viewModel)
                                    AppScreen.Optimizer -> OptimizerScreen(viewModel = viewModel)
                                    AppScreen.QuickPricing -> QuickPricingScreen(viewModel = viewModel)
                                    AppScreen.Settings -> SettingsScreen(viewModel = viewModel)
                                    else -> {}
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
